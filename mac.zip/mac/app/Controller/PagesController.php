<?php
/**
 * Static content controller.
 *
 * This file will render views from views/pages/
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link http://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class PagesController extends AppController {

/**
 * This controller does not use a model
 *
 * @var array
 */
	
	public $uses = array();
	public function beforeFilter(){
		$this->Auth->allow('home','addCity','increaseQty','addToCart','myCart','removeCartItem');
	}
/**
 * Displays a view
 *
 * @param mixed What page to display
 * @return void
 * @throws NotFoundException When the view file could not be found
 *	or MissingViewException in debug mode.
 */
	public function display() {
		$path = func_get_args();

		$count = count($path);
		if (!$count) {
			return $this->redirect('/');
		}
		$page = $subpage = $title_for_layout = null;

		if (!empty($path[0])) {
			$page = $path[0];
		}
		if (!empty($path[1])) {
			$subpage = $path[1];
		}
		if (!empty($path[$count - 1])) {
			$title_for_layout = Inflector::humanize($path[$count - 1]);
		}
		$this->set(compact('page', 'subpage', 'title_for_layout'));

		try {
			$this->render(implode('/', $path));
		} catch (MissingViewException $e) {
			if (Configure::read('debug')) {
				throw $e;
			}
			throw new NotFoundException();
		}
	}
	
	public function home(){
		$this->loadModel('City');
		
		
		$this->loadModel('Item');
		
		$cartData=$this->Session->read('cartData');
		$cart_count=count($cartData);
		$this->set(compact('cart_count'));
		
		$item_list=$this->Item->find('all',array('conditions'=>array('Item.is_deleted'=>0)));
		$this->set(compact('item_list'));
		
	
	}
	
	public function addToCart($id,$price,$image,$name) {
		$this->autoRendor=false;
		//$cartData=$this->Session->delete('cartData');
		$cartData=$this->Session->read('cartData');
		$cartData[$id]['item_id']=$id;
		$cartData[$id]['image']=$image;
		$cartData[$id]['name']=$name;
		$cartData[$id]['qty']=1;
		$cartData[$id]['price']=$price;
		$this->Session->write('cartData',$cartData);
		$this->redirect(array('action'=>'home'));

	}

	public function myCart(){
		
		
		$cartData=$this->Session->read('cartData');
		$this->set(compact('cartData'));
		
		
		
	
	}
	
	public function removeCartItem($id=null){
		
		$cartData=$this->Session->read('cartData');
		unset($cartData[$id]);
		;
		$this->Session->write('cartData',$cartData);
		$this->redirect(array('action'=>'myCart'));
		
	}
	public function increaseQty(){
		
		
		$this->autoRender = FALSE;
		$this->layout = 'ajax';

		if ($this->request->is('ajax')) 
			{
				$id=$this->request->data['id'];
				$qty=$this->request->data['qty'];
				$cartData=$this->Session->read('cartData');

				$cartData[$id]['qty']=$qty;

				
				if ($this->Session->write('cartData',$cartData)) 
				{
						
					echo json_encode(array('status'=>'200','message'=>'successfully'));
				} 
				else 
				{
					echo json_encode(array('status'=>'400','message'=>' could not be added'));
				}
			}				
		
		else
		{
			$this->Session->setFlash("Unauthorized access", 'error');
            $this->redirect($this->referer());
		}
		
		
	}
	
	public function checkout(){
		
		$this->loadModel('Order');
		$this->loadModel('OrderDetail');
		
		$cartData=$this->Session->read('cartData');
		$this->set(compact('cartData'));
		
		if($this->request->is('post'))
		{
			
			if(!empty($this->request->data['Order']))
			{
				$this->request->data['Order']['user_id']=$this->Session->read('Auth.User.id');
				if($this->Order->save($this->request->data['Order'])){
					$order_id=$this->Order->getInsertID();
					if(!empty($cartData))
					{
						foreach($cartData as $row)
						{
							$this->OrderDetail->create();
							$detailsdata=array(
							'order_id'=>$order_id,
							'item_id'=>$row['item_id'],
							'qty'=>$row['qty'],
							'price'=>$row['price'],
							'total'=>$row['price']*$row['qty']
							
							);							
							$this->OrderDetail->save($detailsdata);
						}
					}
					$this->Session->delete('cartData');
					$this->Session->setFlash('Order Place successfully','success');
					$this->redirect(array('action'=>'home'));
					
				}
			}
		}
		
	
	}
	
	public function addCity(){
		$this->loadModel('City');
		
		if($this->request->is('post')){
			if($this->City->save($this->request->data['City'])){
				$this->Session->setFlash('City add successfully','error');
			}
		}
		
	}
	
	
	public function login(){
		$this->loadModel('User');
		
		if($this->request->is('post'))
		{
			$password=$this->Auth->Password($this->request->data['User']['password']);
			$data=$this->User->find('first',array('conditions'=>array('User.is_active'=>1,'User.is_deleted'=>0,'User.email'=>$this->request->data['User']['email'],'User.password'=>$password)));
			if($data)
			{
				
				if($this->Auth->login())
				{
					//echo "loggedin";exit;
					$this->redirect(array('controller'=>'pages','action'=>'muCart'));
				}
			}else{
				$this->Session->setFlash('Invalid user id','error');
			}
		}
		
	}
}
